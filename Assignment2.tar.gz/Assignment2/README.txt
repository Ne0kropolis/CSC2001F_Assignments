Author : Fortune Dederen
Name : Binary Search Trees(Assignment 2)
Description: Binary Search Trees creates two binary search trees to store the names and surnames of the textfile toSearchIn.txt and lists their information(keys, name, count).
Instructions: Use the Makefile to compile Searcher.java, nameSearcher and surnameSearcher, and run Searcher as the main class.
List of Files: Searcher.java, nameSearchTree.java, surnameSearchTree.java, toSearchIn.txt, Makefile.
